package tr.autoschematic;

import net.minecraft.client.MinecraftClient;
import net.minecraft.world.World;

import java.lang.reflect.Method;
import java.lang.reflect.Modifier;
import java.util.ArrayList;
import java.util.Collection;
import java.util.Collections;
import java.util.List;

/**
 * Litematica köprüsü (reflection). Derleme zamanında Litematica'ya bağımlılık yok.
 * - schematicWorld(): Litematica'nın şematik dünyası (WorldSchematic, ClientWorld alt sınıfı)
 * - placementNames(): yüklü şematik yerleşimlerinin adları
 */
public final class Litema {
    private Litema() {
    }

    private static boolean tried;
    private static Method getWorld;
    private static Object worldHandler;      // getSchematicWorld static ise null
    private static Method getManager;
    private static Method getAll;
    private static Method getName;
    public static List<String> names = Collections.emptyList();
    private static int t;

    private static void init() {
        if (tried) return;
        tried = true;
        try {
            Class<?> h = Class.forName("fi.dy.masa.litematica.world.SchematicWorldHandler");
            getWorld = h.getMethod("getSchematicWorld");
            if (!Modifier.isStatic(getWorld.getModifiers())) {
                worldHandler = h.getField("INSTANCE").get(null);
            }
        } catch (Throwable e) {
            getWorld = null;
        }
        try {
            Class<?> dm = Class.forName("fi.dy.masa.litematica.data.DataManager");
            getManager = dm.getMethod("getSchematicPlacementManager");
        } catch (Throwable e) {
            getManager = null;
        }
    }

    public static boolean present() {
        init();
        return getWorld != null;
    }

    /** Şematik dünyası; yoksa null. */
    public static World schematicWorld() {
        init();
        if (getWorld == null) return null;
        try {
            Object o = getWorld.invoke(worldHandler);
            return o instanceof World w ? w : null;
        } catch (Throwable e) {
            return null;
        }
    }

    public static List<String> placementNames() {
        init();
        List<String> out = new ArrayList<>();
        if (getManager == null) return out;
        try {
            Object pm = getManager.invoke(null);
            if (pm == null) return out;
            if (getAll == null) getAll = pm.getClass().getMethod("getAllSchematicsPlacements");
            Object res = getAll.invoke(pm);
            if (res instanceof Collection<?> col) {
                for (Object o : col) {
                    String n = "?";
                    try {
                        if (getName == null) getName = o.getClass().getMethod("getName");
                        n = String.valueOf(getName.invoke(o));
                    } catch (Throwable ignored) {
                        // isim alınamadı
                    }
                    out.add(n);
                }
            }
        } catch (Throwable ignored) {
            // Litematica henüz hazır değil
        }
        return out;
    }

    /** Saniyede bir şematik var mı diye bakar; ilk yüklemede ekranda haber verir. */
    public static void tick(MinecraftClient mc) {
        if (++t % 20 != 0) return;
        List<String> now = placementNames();
        if (!now.isEmpty() && names.isEmpty()) {
            Util.info(mc, "Şematik algılandı: " + String.join(", ", now));
        }
        names = now;
    }
}
