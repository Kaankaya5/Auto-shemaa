package tr.autoschematic;

import net.minecraft.client.MinecraftClient;
import net.minecraft.item.Item;
import net.minecraft.registry.Registries;

/**
 * Auto Buy: inşa için gereken malzeme envanterde yoksa, ayarlanan komutu sohbetten çalıştırır.
 * Komut şablonunda {item} (örn. stone_bricks), {item_name} (görünen ad) ve {amount} kullanılabilir.
 * Sunucundaki gerçek market komutuna göre Panel > Oyuncu bölümünden değiştir.
 */
public final class Buyer {
    private Buyer() {
    }

    private static int cooldown;

    public static void tick() {
        if (cooldown > 0) cooldown--;
    }

    public static void request(MinecraftClient mc, Item item) {
        Cfg c = Cfg.get();
        if (!c.autoBuy || cooldown > 0 || mc.getNetworkHandler() == null) return;
        String cmd = c.buyCommand == null ? "" : c.buyCommand.trim();
        if (cmd.isEmpty()) return;

        cmd = cmd.replace("{item}", Registries.ITEM.getId(item).getPath())
                .replace("{item_name}", item.getName().getString())
                .replace("{amount}", String.valueOf(c.buyAmount));
        if (cmd.startsWith("/")) cmd = cmd.substring(1);

        mc.getNetworkHandler().sendChatCommand(cmd);
        cooldown = Math.max(20, c.buySeconds * 20);
    }
}
