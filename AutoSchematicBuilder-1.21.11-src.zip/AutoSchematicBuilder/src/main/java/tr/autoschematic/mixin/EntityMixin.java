package tr.autoschematic.mixin;

import net.minecraft.client.MinecraftClient;
import net.minecraft.entity.Entity;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;
import tr.autoschematic.Look;

/** FreeLook açıkken fare hareketi oyuncuyu değil sadece kamerayı çevirir. */
@Mixin(Entity.class)
public abstract class EntityMixin {
    @Inject(method = "changeLookDirection", at = @At("HEAD"), cancellable = true, require = 0)
    private void autoschematic$freelook(double cursorDeltaX, double cursorDeltaY, CallbackInfo ci) {
        if (Look.active && (Object) this == MinecraftClient.getInstance().player) {
            Look.onMouse(cursorDeltaX, cursorDeltaY);
            ci.cancel();
        }
    }
}
