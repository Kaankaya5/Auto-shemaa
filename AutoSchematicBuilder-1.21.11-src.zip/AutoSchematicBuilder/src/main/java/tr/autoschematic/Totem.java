package tr.autoschematic;

import net.minecraft.client.MinecraftClient;
import net.minecraft.client.network.ClientPlayerEntity;
import net.minecraft.client.network.ClientPlayerInteractionManager;
import net.minecraft.entity.player.PlayerInventory;
import net.minecraft.item.Items;
import net.minecraft.screen.slot.SlotActionType;

/** Offhand'de totem yoksa envanterden (hotbar dahil) bir totemi offhand'e koyar. */
public final class Totem {
    private Totem() {
    }

    public static int pops;          // offhand'den totem kaybolma sayısı (yaklaşık)
    private static boolean had;
    private static int wait;

    public static void tick(MinecraftClient mc) {
        Cfg c = Cfg.get();
        ClientPlayerEntity p = mc.player;
        ClientPlayerInteractionManager im = mc.interactionManager;
        if (!c.autoTotem || p == null || im == null) return;
        // Sandık vb. bir konteyner açıksa veya imleçte eşya varsa dokunma
        if (p.currentScreenHandler != p.playerScreenHandler) return;
        if (!p.playerScreenHandler.getCursorStack().isEmpty()) return;

        boolean has = p.getOffHandStack().isOf(Items.TOTEM_OF_UNDYING);
        if (had && !has) pops++;
        had = has;
        if (has) {
            wait = 0;
            return;
        }
        if (wait > 0) {
            wait--;
            return;
        }

        PlayerInventory inv = p.getInventory();
        int found = -1;
        for (int i = 0; i < 36; i++) {
            if (inv.getStack(i).isOf(Items.TOTEM_OF_UNDYING)) {
                found = i;
                break;
            }
        }
        if (found < 0) return;

        // SWAP + 40 = seçilen slot ile offhand'i değiştir
        im.clickSlot(p.playerScreenHandler.syncId, Util.screenSlot(found), 40, SlotActionType.SWAP, p);
        wait = Math.max(0, c.totemDelay);
    }
}
