package tr.autoschematic;

import net.minecraft.block.Block;
import net.minecraft.block.BlockState;
import net.minecraft.block.ShapeContext;
import net.minecraft.client.network.ClientPlayerEntity;
import net.minecraft.client.world.ClientWorld;
import net.minecraft.item.ItemPlacementContext;
import net.minecraft.item.ItemStack;
import net.minecraft.registry.Registries;
import net.minecraft.state.property.Property;
import net.minecraft.util.Hand;
import net.minecraft.util.hit.BlockHitResult;
import net.minecraft.util.math.BlockPos;
import net.minecraft.util.math.Direction;
import net.minecraft.util.math.Vec3d;

import java.util.ArrayList;
import java.util.List;
import java.util.Set;

/**
 * Bir bloğu şematikteki haline getirmek için "nereye, hangi yüzüne, hangi bakışla tıklanmalı" sorusunu çözer.
 *
 * Yöntem: oyunun kendi mantığını kullanır. Her aday (komşu blok yüzü + bakış açısı) için
 * Block#getPlacementState çağrılır; dönen durum şematikteki durumla (yön, yarım blok, eksen vb.)
 * uyuşuyorsa o aday seçilir. Böylece merdiven, fırın, kütük, slab, tabela... için tek tek kural yazmaya gerek kalmaz.
 */
public final class Planner {
    private Planner() {
    }

    public static final class Plan {
        public final BlockPos neighbor;
        public final Direction face;
        public final Vec3d hit;
        public final boolean rotate;
        public final float yaw;
        public final float pitch;

        Plan(BlockPos neighbor, Direction face, Vec3d hit, boolean rotate, float yaw, float pitch) {
            this.neighbor = neighbor;
            this.face = face;
            this.hit = hit;
            this.rotate = rotate;
            this.yaw = yaw;
            this.pitch = pitch;
        }
    }

    /** Komşulara göre değişen / yerleştirme sırasında oyunun kendisinin çözdüğü özellikler: karşılaştırmada yok sayılır. */
    private static final Set<String> IGNORE = Set.of(
            "waterlogged", "powered", "lit", "distance", "persistent", "triggered", "power", "open", "locked",
            "unstable", "enabled", "inverted", "bottom", "attached", "disarmed", "in_wall",
            "north", "east", "south", "west", "up", "down", "shape", "snowy", "age", "moisture", "stage",
            "hinge", "occupied", "has_book", "has_record", "signal_fire", "berries", "tilt", "thickness");

    /** Sağ tıklayınca arayüz açan / bir şey yapan blokların adında geçen parçalar: bunlara karşı yerleştirmeyiz. */
    private static final String[] USABLE = {
            "crafting_table", "note_block", "door", "gate", "button", "lever", "anvil", "_bed", "bell", "cake",
            "candle", "cauldron", "composter", "loom", "cartography", "smithing", "fletching", "grindstone",
            "stonecutter", "enchanting", "lectern", "jukebox", "repeater", "comparator", "daylight",
            "respawn_anchor", "flower_pot", "potted", "command_block", "dragon_egg", "sign", "vault", "trial_spawner"
    };

    /** Aday bakış açıları (yaw 22.5° adımlarla 16 yön x 3 pitch). */
    private static final float[][] ROTS = buildRots();

    private static float[][] buildRots() {
        List<float[]> l = new ArrayList<>();
        float[] pitches = {0f, 90f, -90f};
        for (float pt : pitches) {
            for (int i = 0; i < 16; i++) {
                l.add(new float[]{i * 22.5f, pt});
            }
        }
        return l.toArray(new float[0][]);
    }

    public static Plan plan(ClientWorld w, ClientPlayerEntity p, BlockPos pos, BlockState want,
                            ItemStack stack, double reach) {
        Block block = want.getBlock();
        Vec3d eye = p.getEyePos();
        boolean needRot = hasAny(want, "facing", "rotation", "orientation");
        boolean needHalf = hasAny(want, "half", "type");

        for (Direction d : Direction.values()) {
            BlockPos nb = pos.offset(d);
            BlockState ns = w.getBlockState(nb);
            if (ns.isAir() || ns.isReplaceable() || usable(ns)) continue;

            Direction face = d.getOpposite();   // komşunun, hedef bloğa bakan yüzü
            double[] ys = (needHalf && face.getAxis().isHorizontal()) ? new double[]{0.25, 0.75} : new double[]{0.5};

            for (double yy : ys) {
                Vec3d hit = hitPoint(nb, face, yy);
                if (eye.squaredDistanceTo(hit) > reach * reach) continue;
                BlockHitResult bhr = new BlockHitResult(hit, face, nb, false);

                if (ok(w, p, stack, bhr, block, want, pos, p.getYaw(), p.getPitch())) {
                    return new Plan(nb, face, hit, false, 0f, 0f);
                }
                if (needRot) {
                    for (float[] r : ROTS) {
                        if (ok(w, p, stack, bhr, block, want, pos, r[0], r[1])) {
                            return new Plan(nb, face, hit, true, r[0], r[1]);
                        }
                    }
                }
            }
        }
        return null;
    }

    private static Vec3d hitPoint(BlockPos nb, Direction face, double yy) {
        double x = nb.getX() + 0.5 + face.getOffsetX() * 0.5;
        double y = nb.getY() + 0.5 + face.getOffsetY() * 0.5;
        double z = nb.getZ() + 0.5 + face.getOffsetZ() * 0.5;
        if (face.getAxis().isHorizontal() && yy != 0.5) {
            y = nb.getY() + yy;
        }
        return new Vec3d(x, y, z);
    }

    private static boolean ok(ClientWorld w, ClientPlayerEntity p, ItemStack stack, BlockHitResult hit,
                              Block block, BlockState want, BlockPos pos, float yaw, float pitch) {
        float oy = p.getYaw();
        float op = p.getPitch();
        BlockState got;
        try {
            p.setYaw(yaw);
            p.setPitch(pitch);
            ItemPlacementContext ctx = new ItemPlacementContext(p, Hand.MAIN_HAND, stack, hit);
            if (!ctx.canPlace()) return false;
            got = block.getPlacementState(ctx);
        } catch (Throwable t) {
            return false;
        } finally {
            p.setYaw(oy);
            p.setPitch(op);
        }
        if (got == null || !matches(got, want)) return false;
        if (!got.canPlaceAt(w, pos)) return false;
        return w.canPlace(got, pos, ShapeContext.of(p));
    }

    private static boolean matches(BlockState got, BlockState want) {
        if (got.getBlock() != want.getBlock()) return false;
        for (Property<?> prop : want.getProperties()) {
            String n = prop.getName();
            if (IGNORE.contains(n)) continue;
            Object a = got.get(prop);
            Object b = want.get(prop);
            // sandık "type" (tek/sol/sağ) komşuya göre kendiliğinden belirlenir
            if ("type".equals(n) && a.getClass().getSimpleName().equals("ChestType")) continue;
            if (!a.equals(b)) return false;
        }
        return true;
    }

    private static boolean hasAny(BlockState s, String... names) {
        for (Property<?> p : s.getProperties()) {
            for (String n : names) {
                if (p.getName().equals(n)) return true;
            }
        }
        return false;
    }

    private static boolean usable(BlockState s) {
        if (s.hasBlockEntity()) return true;
        String id = Registries.BLOCK.getId(s.getBlock()).getPath();
        for (String k : USABLE) {
            if (id.contains(k)) return true;
        }
        return false;
    }
}
