package tr.autoschematic;

import com.google.gson.Gson;
import com.google.gson.GsonBuilder;
import net.fabricmc.loader.api.FabricLoader;

import java.nio.file.Files;
import java.nio.file.Path;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;

/**
 * Ayarlar. Alanlar public: Gson bunları doğrudan config/autoschematic.json dosyasına yazar.
 * Dosyayı elle de düzenleyebilirsin (oyun kapalıyken).
 */
public final class Cfg {
    // ---------- İnşa ----------
    public boolean build = false;          // otomatik inşa açık mı
    public int range = 4;                  // blok menzili (1-6, gerçek menzil en fazla oyun menzili kadar)
    public int delay = 2;                  // iki yerleştirme arası tick (0-20)
    public int perTick = 1;                // aynı turda en fazla kaç blok (1-4)
    public boolean layerMode = false;      // true: alttan üste, false: yakından uzağa
    public boolean autoRefill = true;      // malzeme ana envanterdeyse hotbar'a çek
    public int refillSlot = 9;             // hotbar'da hangi slota çekilsin (1-9)
    public boolean pauseLowHealth = true;  // can düşükse duraklat
    public int pauseHealth = 6;            // bu can ve altında duraklat (6 = 3 kalp)

    // ---------- Oyuncu ----------
    public boolean autoTotem = true;
    public int totemDelay = 1;             // tick
    public boolean freeLook = false;
    public boolean autoBuy = false;
    public String buyCommand = "/buy {item} {amount}";
    public int buyAmount = 64;
    public int buySeconds = 5;             // iki satın alma komutu arası saniye

    // ---------- Staff ----------
    public boolean staffAnyRank = false;   // tab listede öneki olan herkesi göster
    public List<String> staffKeywords = new ArrayList<>(Arrays.asList(
            "owner", "founder", "kurucu", "sahip", "admin", "sradmin", "sr", "srmod",
            "mod", "moderator", "moderatör", "helper", "yetkili", "yönetici", "sorumlu",
            "destek", "support", "dev", "developer", "manager", "trainee"));
    public List<String> staffNames = new ArrayList<>();   // ismen eklemek istediklerin (küçük harf)

    private static Cfg inst = new Cfg();
    private static final Gson GSON = new GsonBuilder().setPrettyPrinting().create();

    public static Cfg get() {
        return inst;
    }

    private static Path file() {
        return FabricLoader.getInstance().getConfigDir().resolve("autoschematic.json");
    }

    public static void load() {
        try {
            Path f = file();
            if (Files.exists(f)) {
                Cfg c = GSON.fromJson(Files.readString(f), Cfg.class);
                if (c != null) inst = c;
            }
        } catch (Exception e) {
            System.err.println("[AutoSchematic] ayar okunamadi: " + e);
        }
        inst.sanitize();
        save();
    }

    public static void save() {
        try {
            Files.writeString(file(), GSON.toJson(inst));
        } catch (Exception e) {
            System.err.println("[AutoSchematic] ayar yazilamadi: " + e);
        }
    }

    private static int clamp(int v, int lo, int hi) {
        return Math.max(lo, Math.min(hi, v));
    }

    private void sanitize() {
        range = clamp(range, 1, 6);
        delay = clamp(delay, 0, 20);
        perTick = clamp(perTick, 1, 4);
        refillSlot = clamp(refillSlot, 1, 9);
        pauseHealth = clamp(pauseHealth, 1, 20);
        totemDelay = clamp(totemDelay, 0, 10);
        buyAmount = clamp(buyAmount, 1, 64);
        buySeconds = clamp(buySeconds, 2, 60);
        if (buyCommand == null) buyCommand = "/buy {item} {amount}";
        if (staffKeywords == null) staffKeywords = new ArrayList<>();
        if (staffNames == null) staffNames = new ArrayList<>();
    }
}
