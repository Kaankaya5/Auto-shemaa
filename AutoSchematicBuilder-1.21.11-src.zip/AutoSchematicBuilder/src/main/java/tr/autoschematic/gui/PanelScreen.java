package tr.autoschematic.gui;

import net.minecraft.client.MinecraftClient;
import net.minecraft.client.gui.DrawContext;
import net.minecraft.client.gui.screen.Screen;
import net.minecraft.client.gui.widget.ButtonWidget;
import net.minecraft.client.gui.widget.SliderWidget;
import net.minecraft.client.gui.widget.TextFieldWidget;
import net.minecraft.text.Text;
import net.minecraft.util.Formatting;
import tr.autoschematic.Builder;
import tr.autoschematic.Cfg;
import tr.autoschematic.Litema;
import tr.autoschematic.Materials;
import tr.autoschematic.Staff;
import tr.autoschematic.Totem;

import java.util.List;
import java.util.function.BooleanSupplier;
import java.util.function.Consumer;
import java.util.function.IntConsumer;

/** Tuşa basınca açılan ayar paneli: İnşa | Oyuncu | Malzeme | Staff. */
public class PanelScreen extends Screen {
    private static final int PW = 320;
    private static final int PH = 222;
    private static final int WHITE = 0xFFFFFFFF;
    private static final int GRAY = 0xFFAAAAAA;

    private static int lastTab = 0;
    private int tab = lastTab;
    private int px;
    private int py;

    public PanelScreen() {
        super(Text.literal("Auto Schematic Builder"));
    }

    // ------------------------------------------------------------------ widgets

    @Override
    protected void init() {
        px = (this.width - PW) / 2;
        py = (this.height - PH) / 2;

        String[] names = {"İnşa", "Oyuncu", "Malzeme", "Staff"};
        int tw = 74;
        for (int i = 0; i < names.length; i++) {
            final int idx = i;
            Text label = Text.literal((tab == i ? "» " : "") + names[i]);
            addDrawableChild(ButtonWidget.builder(label, b -> {
                tab = idx;
                lastTab = idx;
                this.clearAndInit();
            }).dimensions(px + 8 + i * (tw + 4), py + 18, tw, 18).build());
        }

        int x = px + 10;
        int w = PW - 20;
        int half = (w - 6) / 2;
        switch (tab) {
            case 0 -> buildTab(x, py + 90, w, half);
            case 1 -> playerTab(x, py + 44, w, half);
            case 2 -> materialTab(x, py + 44, w);
            default -> staffTab(x, py + 44, w);
        }

        addDrawableChild(ButtonWidget.builder(Text.literal("Kapat"), b -> close())
                .dimensions(px + PW - 58, py + PH - 24, 50, 18).build());
    }

    private void buildTab(int x, int y, int w, int half) {
        Cfg c = Cfg.get();
        toggle(x, y, w, "Otomatik İnşa", () -> c.build, v -> c.build = v);
        addDrawableChild(new IntSlider(x, y + 22, half, "Menzil", " blok", 1, 6, c.range, v -> c.range = v));
        addDrawableChild(new IntSlider(x + half + 6, y + 22, half, "Gecikme", " tick", 0, 20, c.delay, v -> c.delay = v));
        addDrawableChild(new IntSlider(x, y + 44, half, "Blok/tur", "", 1, 4, c.perTick, v -> c.perTick = v));
        addDrawableChild(ButtonWidget.builder(sortLabel(c.layerMode), b -> {
            c.layerMode = !c.layerMode;
            b.setMessage(sortLabel(c.layerMode));
        }).dimensions(x + half + 6, y + 44, half, 20).build());
        toggle(x, y + 66, half, "Hotbar'a çek", () -> c.autoRefill, v -> c.autoRefill = v);
        toggle(x + half + 6, y + 66, half, "Can düşükse dur", () -> c.pauseLowHealth, v -> c.pauseLowHealth = v);
    }

    private void playerTab(int x, int y, int w, int half) {
        Cfg c = Cfg.get();
        toggle(x, y, half, "Auto Totem", () -> c.autoTotem, v -> c.autoTotem = v);
        addDrawableChild(new IntSlider(x + half + 6, y, half, "Totem gecikme", " tick", 0, 10, c.totemDelay, v -> c.totemDelay = v));

        toggle(x, y + 22, w, "FreeLook", () -> c.freeLook, v -> c.freeLook = v);

        toggle(x, y + 56, half, "Auto Buy", () -> c.autoBuy, v -> c.autoBuy = v);
        addDrawableChild(new IntSlider(x + half + 6, y + 56, half, "Miktar", "", 1, 64, c.buyAmount, v -> c.buyAmount = v));

        TextFieldWidget tf = new TextFieldWidget(this.textRenderer, x, y + 90, w, 20, Text.literal("Komut"));
        tf.setMaxLength(120);
        tf.setText(c.buyCommand);
        tf.setChangedListener(s -> Cfg.get().buyCommand = s);
        addDrawableChild(tf);

        addDrawableChild(new IntSlider(x, y + 114, w, "Satın alma aralığı", " sn", 2, 60, c.buySeconds, v -> c.buySeconds = v));
    }

    private void materialTab(int x, int y, int w) {
        addDrawableChild(ButtonWidget.builder(Text.literal("Çevredeki malzemeyi hesapla (24 blok)"),
                b -> Materials.scan(MinecraftClient.getInstance(), 24)).dimensions(x, y, w, 20).build());
    }

    private void staffTab(int x, int y, int w) {
        Cfg c = Cfg.get();
        toggle(x, y, w, "Rank'ı olan herkesi göster", () -> c.staffAnyRank, v -> {
            c.staffAnyRank = v;
            Staff.refresh(MinecraftClient.getInstance());
        });
    }

    private ButtonWidget toggle(int x, int y, int w, String label, BooleanSupplier get, Consumer<Boolean> set) {
        ButtonWidget b = ButtonWidget.builder(onOff(label, get.getAsBoolean()), btn -> {
            set.accept(!get.getAsBoolean());
            btn.setMessage(onOff(label, get.getAsBoolean()));
        }).dimensions(x, y, w, 20).build();
        return addDrawableChild(b);
    }

    private static Text onOff(String label, boolean v) {
        return Text.literal(label + ": ")
                .append(Text.literal(v ? "AÇIK" : "KAPALI").formatted(v ? Formatting.GREEN : Formatting.RED));
    }

    private static Text sortLabel(boolean layer) {
        return Text.literal("Sıra: " + (layer ? "alttan üste" : "yakından uzağa"));
    }

    // ------------------------------------------------------------------ drawing

    @Override
    public void renderBackground(DrawContext ctx, int mouseX, int mouseY, float delta) {
        super.renderBackground(ctx, mouseX, mouseY, delta);
        ctx.fill(px, py, px + PW, py + PH, 0xE0141420);
        ctx.fill(px, py, px + PW, py + 2, 0xFF3FA9F5);
    }

    @Override
    public void render(DrawContext ctx, int mouseX, int mouseY, float delta) {
        super.render(ctx, mouseX, mouseY, delta);
        ctx.drawCenteredTextWithShadow(this.textRenderer, this.title, this.width / 2, py + 6, WHITE);

        int x = px + 10;
        switch (tab) {
            case 0 -> drawBuildInfo(ctx, x);
            case 1 -> drawPlayerInfo(ctx, x);
            case 2 -> drawMaterials(ctx, x);
            default -> drawStaff(ctx, x);
        }
    }

    private void line(DrawContext ctx, int x, int y, Text t) {
        ctx.drawTextWithShadow(this.textRenderer, t, x, y, WHITE);
    }

    private void line(DrawContext ctx, int x, int y, String s, int color) {
        ctx.drawTextWithShadow(this.textRenderer, Text.literal(s), x, y, color);
    }

    private static String cut(String s, int max) {
        return s.length() <= max ? s : s.substring(0, max - 1) + "…";
    }

    private void drawBuildInfo(DrawContext ctx, int x) {
        boolean has = Litema.present();
        line(ctx, x, py + 42, Text.literal("Litematica: ")
                .append(Text.literal(has ? "bulundu" : "BULUNAMADI").formatted(has ? Formatting.GREEN : Formatting.RED)));
        List<String> n = Litema.names;
        line(ctx, x, py + 53, "Şematik: " + (n.isEmpty() ? "algılanmadı" : cut(String.join(", ", n), 40)),
                n.isEmpty() ? GRAY : 0xFF55FF55);
        line(ctx, x, py + 64, "Durum: " + cut(Builder.status, 44), WHITE);
        line(ctx, x, py + 75, "Yerleşen: " + Builder.placedTotal + "   |   Menzilde eksik: " + Builder.nearby, GRAY);
    }

    private void drawPlayerInfo(DrawContext ctx, int x) {
        int y = py + 44;
        line(ctx, x, y + 80 - 11, "Satın alma komutu  ({item} {item_name} {amount}):", GRAY);
        line(ctx, x, y + 22 + 22, "FreeLook tuşu: Kontroller > Auto Schematic Builder", GRAY);
        line(ctx, x, y + 138, "Patlayan totem (yaklaşık): " + Totem.pops, GRAY);
    }

    private void drawMaterials(DrawContext ctx, int x) {
        line(ctx, x, py + 68, Materials.note, GRAY);
        int y = py + 80;
        int shown = 0;
        for (Materials.Row r : Materials.rows) {
            if (shown >= 8) break;
            boolean enough = r.have >= r.need;
            Text t = Text.literal(cut(r.item.getName().getString(), 28))
                    .append(Text.literal("   " + r.have + " / " + r.need)
                            .formatted(enough ? Formatting.GREEN : Formatting.RED));
            line(ctx, x, y, t);
            y += 11;
            shown++;
        }
        if (Materials.rows.size() > shown) {
            line(ctx, x, y, "... +" + (Materials.rows.size() - shown) + " çeşit daha", GRAY);
        }
    }

    private void drawStaff(DrawContext ctx, int x) {
        List<Staff.Entry> list = Staff.list;
        line(ctx, x, py + 70, "Çevrimiçi yetkili / rank'lı: " + list.size(), GRAY);
        int y = py + 82;
        int shown = 0;
        for (Staff.Entry e : list) {
            if (shown >= 9) break;
            Text t = Text.literal("• ").append(e.shown)
                    .append(Text.literal("  [" + e.rank + "]").formatted(Formatting.GRAY));
            line(ctx, x, y, t);
            y += 11;
            shown++;
        }
        if (list.size() > shown) {
            line(ctx, x, y, "... +" + (list.size() - shown) + " kişi daha", GRAY);
        }
        if (list.isEmpty()) {
            line(ctx, x, y, "Kimse bulunamadı (tab listesi önekine göre aranır).", GRAY);
        }
    }

    // ------------------------------------------------------------------ misc

    @Override
    public void removed() {
        Cfg.save();
        super.removed();
    }

    @Override
    public boolean shouldPause() {
        return false;
    }

    /** Tamsayı kaydırıcı. */
    private static final class IntSlider extends SliderWidget {
        private final String label;
        private final String unit;
        private final int min;
        private final int max;
        private final IntConsumer set;

        IntSlider(int x, int y, int w, String label, String unit, int min, int max, int val, IntConsumer set) {
            super(x, y, w, 20, Text.empty(), (val - min) / (double) (max - min));
            this.label = label;
            this.unit = unit;
            this.min = min;
            this.max = max;
            this.set = set;
            updateMessage();
        }

        private int current() {
            return min + (int) Math.round(this.value * (max - min));
        }

        @Override
        protected void updateMessage() {
            setMessage(Text.literal(label + ": " + current() + unit));
        }

        @Override
        protected void applyValue() {
            set.accept(current());
        }
    }
}
