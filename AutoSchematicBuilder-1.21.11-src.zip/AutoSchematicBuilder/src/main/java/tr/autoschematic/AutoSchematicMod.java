package tr.autoschematic;

import net.fabricmc.api.ClientModInitializer;
import net.fabricmc.fabric.api.client.event.lifecycle.v1.ClientTickEvents;
import net.fabricmc.fabric.api.client.keybinding.v1.KeyBindingHelper;
import net.minecraft.client.MinecraftClient;
import net.minecraft.client.option.KeyBinding;
import net.minecraft.client.util.InputUtil;
import net.minecraft.util.Identifier;
import org.lwjgl.glfw.GLFW;
import tr.autoschematic.gui.PanelScreen;

public class AutoSchematicMod implements ClientModInitializer {
    public static final String ID = "autoschematic";

    /** Paneli açan tuş (Seçenekler > Kontroller > Tuş Atamaları > Auto Schematic Builder). */
    public static KeyBinding openKey;
    /** FreeLook (basılı tutarken). Varsayılan: atanmamış. */
    public static KeyBinding freeLookKey;

    @Override
    public void onInitializeClient() {
        Cfg.load();

        KeyBinding.Category category = KeyBinding.Category.create(Identifier.of(ID, "main"));
        openKey = KeyBindingHelper.registerKeyBinding(
                new KeyBinding("key." + ID + ".panel", InputUtil.Type.KEYSYM, GLFW.GLFW_KEY_RIGHT_SHIFT, category));
        freeLookKey = KeyBindingHelper.registerKeyBinding(
                new KeyBinding("key." + ID + ".freelook", InputUtil.Type.KEYSYM, GLFW.GLFW_KEY_UNKNOWN, category));

        ClientTickEvents.END_CLIENT_TICK.register(AutoSchematicMod::tick);
    }

    private static void tick(MinecraftClient mc) {
        while (openKey.wasPressed()) {
            if (mc.player != null && mc.currentScreen == null) {
                mc.setScreen(new PanelScreen());
            }
        }
        if (mc.player == null || mc.world == null) {
            Look.active = false;
            return;
        }
        Look.tick(mc);
        Totem.tick(mc);      // önce hayatta kalma
        Staff.tick(mc);
        Litema.tick(mc);
        Builder.tick(mc);
        Buyer.tick();
    }
}
