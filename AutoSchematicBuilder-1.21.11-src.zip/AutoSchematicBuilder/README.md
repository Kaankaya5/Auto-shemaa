# Auto Schematic Builder — Fabric 1.21.11

Litematica şematiklerini algılayan, tek tuşla açılan panelden yönetilen inşa yardımcısı.

## Oyunda gerekenler (mods klasörü)
- Fabric Loader 0.18.1 veya üstü (Minecraft 1.21.11)
- Fabric API (1.21.11 sürümü)
- Litematica + MaLiLib (1.21.11 sürümleri)

## .jar'ı GitHub'da derletme (bilgisayarında hiçbir şey kurmadan)
GitHub'ın kendi sunucusu projeyi derler ve sonucu **çıplak .jar** olarak "Releases" sayfasına koyar.

1. github.com → **New repository** → ad: `autoschem` → **Private** → "Add a README file" işaretli → **Create**.
2. Repoda **Add file → Upload files** → `AutoSchematicBuilder-1.21.11-src.zip` dosyasını **zip olarak, açmadan** yükle → **Commit changes**.
3. **Add file → Create new file** → ad kutusuna tam olarak `.github/workflows/build.yml` yaz → içine `build.yml` dosyasının
   tüm içeriğini yapıştır → **Commit changes**. (Klasörü açıp dosyaları tek tek yüklediysen bu adım gerekmez, workflow zaten içinde.)
4. Üstte **Actions** sekmesi → `build-jar` çalışır (3–6 dk). Başlamazsa: Actions → build-jar → **Run workflow**.
5. Yeşil tik olunca repo ana sayfasında sağdaki **Releases** → en üstteki build → **Assets** altındaki
   `AutoSchematicBuilder-1.21.11.jar` dosyasını indir (zip değil, doğrudan .jar).
6. Kırmızı olursa: run sayfasında **Summary** içindeki "Derleme başarısız" kutusunu kopyalayıp Claude'a yapıştır.
   Düzeltilmiş zip'i **aynı adla** tekrar yükle (üzerine yazar), yeni build otomatik başlar.

Workflow, jar'ı ancak derleme başarılı olursa ve sınıflar oyunun kullandığı adlara çevrilmişse (remap) yayınlar.

## (İstersen) kendi bilgisayarında derleme
JDK 21 + IntelliJ IDEA: klasörü "Open" ile aç → Gradle senkronu bitsin → Gradle paneli → Tasks → build → **build**.
Ya da Gradle 9.2.1 kuruluysa `gradle build`. Çıktı: `build/libs/autoschematic-1.0.0.jar` (`-sources.jar` olan değil).

## Kullanım
1. **Seçenekler → Kontroller → Tuş Atamaları → Auto Schematic Builder** altında iki tuş var:
   - **Paneli aç** (varsayılan: Sağ Shift) — istediğin tuşa çevir.
   - **FreeLook (basılı tut)** — varsayılan atanmamış.
2. Litematica'da şematiği yükle ve yerleştir. Mod şematiği algılayınca ekranda
   "Şematik algılandı" yazar (panelde de görünür).
3. Paneli aç → **İnşa** sekmesinde **Otomatik İnşa**'yı aç.

## Panel
- **İnşa:** Otomatik İnşa, menzil, gecikme, blok/tur, sıralama (yakından uzağa / alttan üste),
  malzemeyi hotbar'a çekme, can düşükse duraklatma, canlı durum.
- **Oyuncu:** Auto Totem (offhand), FreeLook, Auto Buy (komut şablonu, miktar, aralık).
- **Malzeme:** çevredeki (24 blok) eksik blokların listesi ve envanterinle karşılaştırması.
- **Staff:** tab listesindeki önek/rank'a göre çevrimiçi yetkililer ("rank'ı olan herkes" anahtarı var).

## Auto Buy nasıl çalışır?
İnşa için gereken blok envanterde yoksa, ayarladığın komut sohbetten çalıştırılır.
Şablon: `/buy {item} {amount}` — `{item}` = `stone_bricks` gibi kimlik, `{item_name}` = görünen ad,
`{amount}` = miktar. Sunucundaki gerçek market komutuna göre Panel → Oyuncu'dan değiştir.
(Menü/GUI tıklaması gerektiren marketlerde çalışmaz.)

## Sınırlamalar (v1)
- Blok kırmaz veya değiştirmez; yalnızca boş / değiştirilebilir (hava, su, ot...) yerlere koyar.
- Yön gerektiren bloklarda (merdiven, fırın, slab, kütük...) oyunun kendi yerleştirme mantığını
  simüle eder; nadir bloklarda yön yanlış çıkabilir.
- Çift slab'ın ikinci yarısı, kapı/yatak gibi iki parçalı blokların üst parçası ayrıca yerleştirilmez.
- Sağ tıklanınca bir şey açan/yapan bloklara (sandık, tezgah, kapı, düğme...) karşı yerleştirme yapmaz.
- Litematica'ya derleme zamanında bağlı değil (reflection); Litematica güncellenip iç isimleri
  değişirse panel "BULUNAMADI" der, oyun çökmez.

## Ayarlar
`config/autoschematic.json` — oyun kapalıyken elle de düzenlenebilir
(staff anahtar kelimeleri, ismen eklenecek kişiler dahil).

## Sorun giderme
- FreeLook çalışmıyorsa `logs/latest.log` içinde "Mixin" satırlarına bak (çökme yapmaz, sadece devre dışı kalır).
- Totem/inşa çalışmıyorsa panelde ilgili anahtarın AÇIK olduğundan ve başka bir menünün açık olmadığından emin ol.

## Not
Bu tür modlar birçok sunucunun kurallarında yasaktır. Kullanım ve sonuçları sana aittir.
Bu projede kod gizleme/şifreleme **yoktur**.
